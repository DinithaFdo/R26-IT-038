"""Legacy compatibility shims required by the DisVoice research pipeline.

The Glottal branch's IAIF/glottal-source features are extracted with
``disvoice.glottal.glottal.Glottal`` (DisVoice 0.1.10), a research library
written against older NumPy/SciPy APIs. This module applies the minimum set
of aliases needed for it to import and run under this project's pinned
NumPy 2.x / SciPy stack, and nothing else. Every alias is added only when the
modern name is missing, so a future NumPy/SciPy release that keeps these
names is never overwritten.

Call :func:`apply_disvoice_compatibility_patches` once, before importing
``disvoice`` -- ``app.models.preprocessing.glottal_v1`` does this lazily on
first use so a deployment that never enables the Glottal branch in real mode
never imports DisVoice (and its heavy ``tensorflow``/``pysptk`` transitive
dependencies) at all.
"""

from __future__ import annotations

import sys
import warnings

_PATCHED = False


def apply_disvoice_compatibility_patches() -> None:
    """Idempotent: safe to call more than once, only patches what's missing."""

    global _PATCHED
    if _PATCHED:
        return

    import numpy as np
    import scipy
    import scipy.integrate as scipy_integrate

    if not hasattr(scipy_integrate, "cumtrapz"):
        scipy_integrate.cumtrapz = scipy_integrate.cumulative_trapezoid
    if not hasattr(scipy, "ifft"):
        import scipy.fft

        scipy.ifft = scipy.fft.ifft
    for name, value in (
        ("Inf", np.inf),
        ("Infinity", np.inf),
        ("NaN", np.nan),
        ("infty", np.inf),
    ):
        if not hasattr(np, name):
            setattr(np, name, value)
    if not hasattr(sys, "warn"):
        sys.warn = warnings.warn

    _PATCHED = True


def patch_disvoice_gci_numpy2_bug() -> None:
    """Fix a DisVoice 0.1.10 bug that NumPy 2.x turns into a hard crash.

    ``disvoice.glottal.GCI.compute_h1h2_hrf_frame`` computes the nearest
    harmonic index with ``posmin = np.where(temp2 == min(temp2))[0]`` (always
    an array), then only squeezes it to a scalar ``if len(posmin) > 1``. When
    there is a unique minimum (``len(posmin) == 1``, the common case),
    ``posmin`` stays a length-1 array and the subsequent
    ``f0_idx[mp] = posmin`` assignment relies on NumPy silently squeezing a
    length-1 array into a scalar slot. NumPy < 2 tolerated that (with a
    deprecation warning); NumPy 2.x raises ``ValueError: setting an array
    element with a sequence``, which would otherwise make H1H2/HRF -- and so
    the whole Glottal branch -- fail on essentially any voiced audio.

    This replaces the function with a byte-for-byte equivalent that always
    takes ``posmin[0]``, which is what both branches of the original
    ``if len(posmin) > 1`` conditional actually reduce to. The algorithm and
    its output are unchanged; only the array/scalar handling is fixed.

    DisVoice's own ``sys.path`` manipulation (each submodule does
    ``sys.path.append(<its own directory>)`` and its sibling modules import
    each other by bare name, e.g. ``from GCI import ...``) means the module
    ``disvoice.glottal.glottal`` actually calls is registered in
    ``sys.modules`` under the bare name ``"GCI"``, a *different* module object
    from ``disvoice.glottal.GCI``. Patching the properly-qualified module has
    no effect on the code path that actually runs, so this patches the bare
    ``"GCI"`` module directly. Must be called only after
    ``disvoice.glottal.glottal`` has been imported at least once (which is
    what registers ``sys.modules["GCI"]``).
    """

    gci_module = sys.modules.get("GCI")
    if gci_module is None:
        raise RuntimeError(
            "disvoice.glottal.glottal must be imported before patching its "
            "'GCI' submodule."
        )
    if getattr(gci_module, "_multiscope_h1h2_hrf_patched", False):
        return

    import numpy as np

    original_peakdetect = sys.modules["peakdetect"].peakdetect
    min_harm_num = gci_module.min_harm_num
    hrf_freq_max = gci_module.HRF_freq_max

    def _patched_compute_h1h2_hrf_frame(GCIn, T0, T0_num, gfd, F0, fs):
        if GCIn - int((T0 * T0_num) / 2) > 0:
            f_start = int(GCIn - int((T0 * T0_num) / 2))
        else:
            f_start = 0
        if GCIn + int((T0 * T0_num) / 2) <= len(gfd):
            f_stop = int(GCIn + int((T0 * T0_num) / 2))
        else:
            f_stop = len(gfd)
        f_frame = gfd[f_start:f_stop]
        f_win = f_frame * np.hamming(len(f_frame))
        f_spec = 20 * np.log10(np.abs(np.fft.fft(f_win, fs)))
        f_spec = f_spec[0 : int(len(f_spec) / 2)]
        max_peaks, _min_peaks = original_peakdetect(f_spec, lookahead=int(T0))

        if len(max_peaks) == 0:
            return 0, 0
        h_idx, h_amp = zip(*max_peaks)
        hrf_harm_num = np.fix(hrf_freq_max / F0)
        H1H2 = 0
        HRF = 0
        if len(h_idx) >= min_harm_num:
            temp1 = np.arange(hrf_harm_num) * F0
            f0_idx = np.zeros(len(h_idx))
            for mp in range(len(h_idx)):
                temp2 = h_idx[mp] - temp1
                temp2 = np.abs(temp2)
                posmin = np.where(temp2 == min(temp2))[0]
                # Original code: `if len(posmin) > 1: posmin = posmin[0]`.
                # Both branches of that conditional reduce to "take the first
                # match" -- unconditionally squeezing here preserves the
                # original result while avoiding the NumPy 2.x assignment
                # error described above.
                posmin = int(posmin[0])
                if posmin < len(h_idx):
                    f0_idx[mp] = posmin
                else:
                    f0_idx[mp] = len(h_idx) - 1
            f0_idx = [int(mm) for mm in f0_idx]
            H1H2 = h_amp[f0_idx[0]] - h_amp[f0_idx[1]]
            harms = [h_amp[mm] for mm in f0_idx[1:]]
            HRF = sum(harms) / h_amp[f0_idx[0]]
        return H1H2, HRF

    gci_module.compute_h1h2_hrf_frame = _patched_compute_h1h2_hrf_frame
    gci_module._multiscope_h1h2_hrf_patched = True
